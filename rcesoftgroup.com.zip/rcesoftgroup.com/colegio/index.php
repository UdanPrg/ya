<?php
	require_once 'vendor/core/config.php';

	require_once 'vendor/Includes/PHPMailer/PHPMailerAutoload.php';
	require_once 'vendor/Includes/Twig/Autoloader.php';

	require_once 'vendor/core/common.php';
	require_once 'vendor/Slim/Slim.php';


	\Slim\Slim::registerAutoloader();
	Twig_Autoloader::register();

	$app = new \Slim\Slim(array(
		'config' => $config,
		'host' => 'http://rcesoftgroup.com/colegio/',
		'directorio' => dirname(__FILE__),
		'debug' => true,
		'log.enabled' => true,
		'templates.path' => 'vendor/Templates/',
		'view' => new \Slim\Views\Twig()
	));

	$app->hook('slim.before.dispatch', function() use ($app) {
		$req = $app->request();

		$app->view()->setData('host', $app->config('host'));
		$app->view()->setData('request', $req->getResourceUri());

		$app->view()->setData('static_site', $app->config('host') . 'static/');
	});

	require_once 'vendor/Routes/home.php';

	$app->run();